"use client";
import { useMemo, useState } from "react";
import BreathCoach from "@/components/BreathCoach";
import AnxietyMode from "@/components/AnxietyMode";
import SleepMode from "@/components/SleepMode";
import Sounds from "@/components/Sounds";
import Card from "@/components/ui/Card";

type Tab = "home" | "respirar" | "ansioso" | "sono" | "sons";

export default function Page() {
  const [tab, setTab] = useState<Tab>("home");

  const header = useMemo(() => {
    const titles: Record<Tab, { title: string; subtitle: string }> = {
      home: { title: "Respira", subtitle: "Um minuto pode mudar seu dia." },
      respirar: { title: "Respirar agora", subtitle: "Siga o ritmo. Um passo de cada vez." },
      ansioso: { title: "Estou ansioso", subtitle: "Você está seguro. Vamos acalmar juntos." },
      sono: { title: "Quero dormir", subtitle: "Desacelere. Seu corpo sabe descansar." },
      sons: { title: "Sons calmantes", subtitle: "Escolha um som e fique um pouco aqui." },
    };
    return titles[tab];
  }, [tab]);

  return (
    <main className="min-h-screen px-4 py-6">
      <div className="mx-auto max-w-md">
        <div className="mb-5">
          <h1 className="text-3xl font-semibold tracking-tight">{header.title}</h1>
          <p className="text-sm text-slate-600 mt-1">{header.subtitle}</p>
        </div>

        {tab === "home" && (
          <div className="space-y-3">
            <Card title="🌬 Respiração guiada" description="Entre no ritmo (1 minuto)." onClick={() => setTab("respirar")} />
            <Card title="😰 Estou ansioso" description="Respiração + aterramento 5-4-3-2-1." onClick={() => setTab("ansioso")} />
            <Card title="🌙 Quero dormir" description="Respiração lenta + tela escura." onClick={() => setTab("sono")} />
            <Card title="🎧 Sons calmantes" description="Chuva / mar / ruído branco." onClick={() => setTab("sons")} />
            <div className="pt-2 text-xs text-slate-500">
              No celular: menu do navegador → <b>Adicionar à tela inicial</b>.
            </div>
          </div>
        )}

        {tab === "respirar" && <BreathCoach onBack={() => setTab("home")} />}
        {tab === "ansioso" && <AnxietyMode onBack={() => setTab("home")} />}
        {tab === "sono" && <SleepMode onBack={() => setTab("home")} />}
        {tab === "sons" && <Sounds onBack={() => setTab("home")} />}
      </div>
    </main>
  );
}
