import "./globals.css";
import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: "Respira",
  description: "Calma em 1 minuto: respiração guiada e sons calmantes.",
  applicationName: "Respira",
  appleWebApp: { capable: true, title: "Respira", statusBarStyle: "default" },
};

export const viewport: Viewport = {
  themeColor: "#93c5fd",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="font-sans">{children}</body>
    </html>
  );
}
