import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Respira",
    short_name: "Respira",
    description: "Calma em 1 minuto. Respiração guiada e sons calmantes.",
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#93c5fd",
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" }
    ],
  };
}
