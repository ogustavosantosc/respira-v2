"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import Button from "@/components/ui/Button";
import SecondaryButton from "@/components/ui/SecondaryButton";
import Chip from "@/components/ui/Chip";

type Sound = "rain" | "ocean" | "white";

function createNoise(ctx: AudioContext) {
  const bufferSize = 2 * ctx.sampleRate;
  const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const output = noiseBuffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) output[i] = Math.random() * 2 - 1;
  const noise = ctx.createBufferSource();
  noise.buffer = noiseBuffer;
  noise.loop = true;
  return noise;
}

export default function Sounds({ onBack }: { onBack: () => void }) {
  const [active, setActive] = useState<Sound | null>(null);
  const [playing, setPlaying] = useState(false);

  const ctxRef = useRef<AudioContext | null>(null);
  const nodeRef = useRef<{ source?: AudioBufferSourceNode; gain?: GainNode; filter?: BiquadFilterNode; lfo?: OscillatorNode; lfoGain?: GainNode } | null>(null);

  const label = useMemo(() => {
    const map: Record<Sound, string> = { rain: "Chuva", ocean: "Mar", white: "Ruído branco" };
    return active ? map[active] : "Nenhum";
  }, [active]);

  const stop = () => {
    try { nodeRef.current?.source?.stop(); nodeRef.current?.lfo?.stop(); } catch {}
    nodeRef.current = null;
    setPlaying(false);
  };

  const ensureCtx = async () => {
    if (!ctxRef.current) ctxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctxRef.current.state === "suspended") await ctxRef.current.resume();
    return ctxRef.current;
  };

  const play = async (sound: Sound) => {
    const ctx = await ensureCtx();
    stop();

    const noise = createNoise(ctx);
    const gain = ctx.createGain();
    gain.gain.value = 0.0;

    const filter = ctx.createBiquadFilter();
    filter.type = sound === "white" ? "allpass" : "lowpass";
    filter.frequency.value = sound === "ocean" ? 400 : 1200;

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    const t = ctx.currentTime;
    gain.gain.setValueAtTime(0.0, t);
    gain.gain.linearRampToValueAtTime(0.18, t + 0.7);

    let lfo: OscillatorNode | undefined;
    let lfoGain: GainNode | undefined;
    if (sound === "ocean") {
      lfo = ctx.createOscillator();
      lfo.type = "sine";
      lfo.frequency.value = 0.12;
      lfoGain = ctx.createGain();
      lfoGain.gain.value = 180;
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);
      lfo.start();
    }

    noise.start();
    nodeRef.current = { source: noise, gain, filter, lfo, lfoGain };
    setActive(sound);
    setPlaying(true);
  };

  useEffect(() => {
    return () => {
      stop();
      ctxRef.current?.close().catch(() => {});
      ctxRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="space-y-3">
      <div className="rounded-2xl bg-white/70 border border-slate-200 shadow-sm p-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-slate-600">Tocando</div>
          <Chip label={playing ? label : "Parado"} />
        </div>
        <p className="text-xs text-slate-500 mt-2">
          Se não tocar, toque em “Iniciar” e aumente o volume do celular.
        </p>
      </div>

      <Button onClick={() => play("rain")}>🌧 Iniciar chuva</Button>
      <SecondaryButton onClick={() => play("ocean")}>🌊 Iniciar mar</SecondaryButton>
      <SecondaryButton onClick={() => play("white")}>📻 Iniciar ruído branco</SecondaryButton>

      <SecondaryButton onClick={stop} disabled={!playing}>⏹ Parar</SecondaryButton>
      <SecondaryButton onClick={onBack}>← Voltar</SecondaryButton>
    </div>
  );
}
