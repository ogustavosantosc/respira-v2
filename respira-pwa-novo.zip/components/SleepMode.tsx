"use client";
import { useState } from "react";
import SecondaryButton from "@/components/ui/SecondaryButton";
import Button from "@/components/ui/Button";

export default function SleepMode({ onBack }: { onBack: () => void }) {
  const [dim, setDim] = useState(false);

  return (
    <div className="space-y-4">
      <div className={"rounded-2xl border shadow-sm p-4 " + (dim ? "bg-slate-950 text-slate-50 border-slate-800" : "bg-white/70 border-slate-200")}>
        <div className="text-base font-semibold">Modo sono</div>
        <p className={"text-sm mt-1 " + (dim ? "text-slate-200" : "text-slate-700")}>
          Inspire 4s e expire 8s (sem segurar). Faça por alguns minutos.
        </p>
        <p className={"text-xs mt-3 " + (dim ? "text-slate-300" : "text-slate-500")}>
          Dica: quando o corpo “pesar”, deixe o celular de lado.
        </p>
      </div>

      <Button onClick={() => setDim(!dim)}>{dim ? "☀️ Voltar luz" : "🌙 Escurecer tela"}</Button>
      <SecondaryButton onClick={onBack}>← Voltar</SecondaryButton>
    </div>
  );
}
