"use client";
import { ButtonHTMLAttributes } from "react";
export default function SecondaryButton({ className="", ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={
        "w-full rounded-2xl px-4 py-3 text-base font-medium shadow-sm " +
        "bg-white/70 text-slate-900 hover:bg-white active:scale-[0.99] transition " +
        "border border-slate-200 " +
        className
      }
    />
  );
}
