"use client";
export default function Chip({ label }: { label: string }) {
  return <span className="inline-flex items-center rounded-full border border-slate-200 bg-white/70 px-3 py-1 text-xs text-slate-700">{label}</span>;
}
