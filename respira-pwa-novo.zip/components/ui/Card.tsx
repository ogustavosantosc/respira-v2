"use client";
export default function Card({ title, description, onClick }: { title: string; description: string; onClick: () => void; }) {
  return (
    <button onClick={onClick} className="w-full text-left rounded-2xl p-4 bg-white/70 border border-slate-200 shadow-sm hover:bg-white transition">
      <div className="text-base font-semibold">{title}</div>
      <div className="text-sm text-slate-600 mt-1">{description}</div>
    </button>
  );
}
