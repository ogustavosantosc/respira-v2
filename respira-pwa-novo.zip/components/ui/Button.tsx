"use client";
import { ButtonHTMLAttributes } from "react";
export default function Button({ className="", ...props }: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...props}
      className={
        "w-full rounded-2xl px-4 py-3 text-base font-medium shadow-sm " +
        "bg-slate-900 text-white hover:bg-slate-800 active:scale-[0.99] transition " +
        "disabled:opacity-50 disabled:cursor-not-allowed " +
        className
      }
    />
  );
}
