"use client";
import { useState } from "react";
import Button from "@/components/ui/Button";
import SecondaryButton from "@/components/ui/SecondaryButton";
import BreathCoach from "@/components/BreathCoach";

type Mode = "menu" | "breath" | "ground";

export default function AnxietyMode({ onBack }: { onBack: () => void }) {
  const [mode, setMode] = useState<Mode>("menu");

  if (mode === "breath") {
    return (
      <div className="space-y-4">
        <div className="rounded-2xl bg-white/70 border border-slate-200 shadow-sm p-4">
          <div className="text-base font-semibold">Socorro rápido</div>
          <p className="text-sm text-slate-700 mt-1">Use a respiração guiada por 1 minuto. Se precisar, repita.</p>
        </div>
        <BreathCoach onBack={() => setMode("menu")} />
      </div>
    );
  }

  if (mode === "ground") {
    return (
      <div className="space-y-4">
        <div className="rounded-2xl bg-white/70 border border-slate-200 shadow-sm p-4 space-y-2">
          <div className="text-base font-semibold">Aterramento 5-4-3-2-1</div>
          <ol className="list-decimal pl-5 text-sm text-slate-700 space-y-1">
            <li><b>5</b> coisas que você consegue ver</li>
            <li><b>4</b> coisas que você consegue tocar</li>
            <li><b>3</b> coisas que você consegue ouvir</li>
            <li><b>2</b> coisas que você consegue cheirar</li>
            <li><b>1</b> coisa que você consegue saborear</li>
          </ol>
          <p className="text-xs text-slate-500">Isso ajuda a trazer a mente para o presente.</p>
        </div>
        <SecondaryButton onClick={() => setMode("menu")}>← Voltar</SecondaryButton>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="rounded-2xl bg-white/70 border border-slate-200 shadow-sm p-4">
        <div className="text-base font-semibold">Você está seguro.</div>
        <p className="text-sm text-slate-700 mt-1">Escolha uma opção rápida:</p>
      </div>
      <Button onClick={() => setMode("breath")}>🌬 Respiração guiada</Button>
      <SecondaryButton onClick={() => setMode("ground")}>🧠 Aterramento 5-4-3-2-1</SecondaryButton>
      <SecondaryButton onClick={onBack}>← Voltar</SecondaryButton>
    </div>
  );
}
