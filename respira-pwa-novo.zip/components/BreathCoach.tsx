"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import Button from "@/components/ui/Button";
import SecondaryButton from "@/components/ui/SecondaryButton";
import Chip from "@/components/ui/Chip";

type Phase = "inspire" | "hold" | "exhale";
const phaseLabel: Record<Phase, string> = { inspire: "Inspire", hold: "Segure", exhale: "Expire" };
const nowMs = () => (typeof performance !== "undefined" ? performance.now() : Date.now());

export default function BreathCoach({ onBack }: { onBack: () => void }) {
  const [running, setRunning] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(60);
  const [phase, setPhase] = useState<Phase>("inspire");
  const [inS, setInS] = useState(4);
  const [holdS, setHoldS] = useState(2);
  const [outS, setOutS] = useState(6);

  const totalCycle = inS + holdS + outS;
  const tickRef = useRef<number | null>(null);
  const startRef = useRef<number>(0);

  const reset = () => {
    setRunning(false);
    setSecondsLeft(60);
    setPhase("inspire");
    if (tickRef.current) cancelAnimationFrame(tickRef.current);
    tickRef.current = null;
  };

  const computePhase = (tSec: number): Phase => {
    const pos = tSec % totalCycle;
    if (pos < inS) return "inspire";
    if (pos < inS + holdS) return "hold";
    return "exhale";
  };

  useEffect(() => {
    if (!running) return;
    startRef.current = nowMs();
    const loop = () => {
      const elapsed = (nowMs() - startRef.current) / 1000;
      const left = Math.max(0, 60 - elapsed);
      setSecondsLeft(Math.ceil(left));
      setPhase(computePhase(elapsed));
      if (left <= 0) { setRunning(false); tickRef.current = null; return; }
      tickRef.current = requestAnimationFrame(loop);
    };
    tickRef.current = requestAnimationFrame(loop);
    return () => { if (tickRef.current) cancelAnimationFrame(tickRef.current); tickRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running, inS, holdS, outS]);

  const scale = useMemo(() => (phase === "inspire" ? 1.06 : phase === "hold" ? 1.06 : 0.94), [phase]);

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-white/70 border border-slate-200 shadow-sm p-4">
        <div className="flex items-center justify-between">
          <div className="text-sm text-slate-600">Sessão</div>
          <Chip label={`${secondsLeft}s`} />
        </div>
        <div className="mt-4 flex items-center justify-center">
          <div className="h-56 w-56 rounded-full bg-gradient-to-br from-sky-200 to-indigo-200 border border-slate-200 shadow-inner flex items-center justify-center transition-transform duration-700" style={{ transform: `scale(${scale})` }}>
            <div className="text-center">
              <div className="text-2xl font-semibold">{phaseLabel[phase]}</div>
              <div className="text-sm text-slate-600 mt-1">Ritmo: {inS}-{holdS}-{outS}</div>
            </div>
          </div>
        </div>
        <div className="mt-4 text-xs text-slate-500 leading-relaxed">
          Respire pelo nariz se puder. Se sentir tontura, diminua o ritmo e respire normalmente.
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <SecondaryButton onClick={() => setInS(4)} className={inS === 4 ? "ring-2 ring-sky-300" : ""}>In 4s</SecondaryButton>
        <SecondaryButton onClick={() => setHoldS(2)} className={holdS === 2 ? "ring-2 ring-sky-300" : ""}>Hold 2s</SecondaryButton>
        <SecondaryButton onClick={() => setOutS(6)} className={outS === 6 ? "ring-2 ring-sky-300" : ""}>Out 6s</SecondaryButton>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Button onClick={() => setRunning(true)} disabled={running}>{running ? "Rodando…" : "Começar (1 min)"}</Button>
        <SecondaryButton onClick={reset}>Reiniciar</SecondaryButton>
      </div>

      <SecondaryButton onClick={onBack}>← Voltar</SecondaryButton>
    </div>
  );
}
