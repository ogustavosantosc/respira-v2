# Respira (PWA)
Um app leve de respiração guiada + sons calmantes, pronto para colocar online.

## Rodar localmente
```bash
npm install
npm run dev
```
Abra http://localhost:3000

## Colocar online (Vercel)
- Suba para o GitHub e faça Deploy na Vercel (New Project → Deploy).
- Ou faça upload direto do projeto na Vercel.

Depois, no celular: menu do navegador → **Adicionar à tela inicial**.
